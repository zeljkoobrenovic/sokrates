ace.define("ace/snippets/ocaml",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "ocaml";

});                (function() {
                    ace.require(["ace/snippets/ocaml"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            